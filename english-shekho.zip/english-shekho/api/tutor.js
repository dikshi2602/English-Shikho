export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { text, scene } = req.body;

  if (!text || !scene) {
    return res.status(400).json({ error: 'Missing text or scene' });
  }

  const SCENARIOS = {
    general: "General Talk",
    school: "School / Class",
    shopping: "Shopping",
    doctor: "Doctor Visit",
    interview: "Job Interview",
    phone: "Phone Call"
  };

  const systemPrompt = `You are an English tutor for Bengali-medium Class 8-10 students in West Bengal, India. Your job is to analyze their English sentences and provide corrections with explanations in both English and Bengali.

Context: The student is practicing "${SCENARIOS[scene] || 'General Talk'}" conversations.

When the student sends an English sentence:
1. Give an overall score (0-100) based on grammar correctness
2. If there are errors, show the corrected sentence
3. List each specific error with:
   - What was wrong (in English)
   - Why it's wrong (simple explanation)
   - Bengali explanation (in Bengali script) — keep it simple and encouraging
4. Give pronunciation tips specifically for Bengali speakers (e.g., common Bengali speaker mistakes like pronouncing "v" as "b", silent letters, stress patterns)
5. Give an encouraging tip in Bengali

Respond ONLY with this JSON format:
{
  "score": 85,
  "hasErrors": true,
  "correctedSentence": "The corrected sentence here",
  "errors": [
    {
      "wrong": "exact wrong phrase",
      "right": "corrected phrase",
      "reason": "Simple English reason",
      "bengali": "বাংলায় ব্যাখ্যা"
    }
  ],
  "pronunciationTip": {
    "word": "difficult word",
    "phonetic": "foh-NET-ik",
    "bengaliTip": "Bengali speakers often say X, but correct is Y. বাংলায় টিপস।"
  },
  "encouragement": "Bengali encouragement message এখানে!"
}

If the sentence is perfect, set hasErrors to false and errors to [].
Keep Bengali explanations simple — Class 8-10 level students.
Be encouraging, never harsh.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: "user", content: text }]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(500).json({ error: 'API error', detail: data });
    }

    const rawText = data.content.map(c => c.text || '').join('');
    const clean = rawText.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);

    return res.status(200).json(result);

  } catch (err) {
    return res.status(500).json({ error: 'Server error', detail: err.message });
  }
}
