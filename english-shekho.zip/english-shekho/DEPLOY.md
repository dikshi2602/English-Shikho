# English Shekho — Deployment Guide
## Deploy to Vercel in 10 minutes (No developer needed)

---

## WHAT YOU NEED
- A free GitHub account (github.com)
- A free Vercel account (vercel.com)
- Your Anthropic API key (console.anthropic.com)

---

## STEP 1 — Upload files to GitHub

1. Go to github.com and sign in
2. Click the "+" button (top right) → "New repository"
3. Name it: `english-shekho`
4. Click "Create repository"
5. Click "uploading an existing file"
6. Upload ALL 3 files:
   - `index.html`
   - `vercel.json`
   - `api/tutor.js` ← make sure to keep it inside a folder called "api"
7. Click "Commit changes"

---

## STEP 2 — Deploy on Vercel

1. Go to vercel.com and sign in with your GitHub account
2. Click "Add New Project"
3. Find "english-shekho" in the list → click "Import"
4. Click "Deploy" (don't change any settings)
5. Wait ~1 minute

---

## STEP 3 — Add your API Key (IMPORTANT)

Without this step, the tool won't work.

1. In Vercel, go to your project → "Settings" tab
2. Click "Environment Variables" in the left menu
3. Add:
   - Name:  `ANTHROPIC_API_KEY`
   - Value: your API key (starts with `sk-ant-...`)
4. Click "Save"
5. Go to "Deployments" tab → click the 3 dots on latest deployment → "Redeploy"

---

## STEP 4 — Get your URL

Vercel gives you a URL like:
`https://english-shekho.vercel.app`

Share this with students. Done.

---

## COST ESTIMATE

- GitHub: Free
- Vercel hosting: Free
- Anthropic API: ~₹0.50–1 per student per session (depends on usage)

Set a monthly budget limit at console.anthropic.com → Billing → Usage Limits
Recommended: start with ₹500/month limit

---

## IF SOMETHING GOES WRONG

- Tool shows error → Check that API key is added correctly in Vercel (Step 3)
- Page doesn't load → Check all 3 files are uploaded including api/tutor.js
- Need help → Share the Vercel error log with your developer

